import os
import re
import subprocess
import tempfile
from pathlib import Path

import streamlit as st
import whisper

st.set_page_config(page_title="DarkCut AI", page_icon="🎬", layout="centered")

st.title("🎬 DarkCut AI")
st.subheader("Transforme vídeos longos em Shorts")


def is_youtube_url(url: str) -> bool:
    return bool(re.match(r"^https?://(www\.)?(youtube\.com|youtu\.be)/", url.strip(), re.I))


def save_uploaded_video(uploaded_file):
    suffix = Path(uploaded_file.name).suffix.lower() or ".mp4"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.write(uploaded_file.getbuffer())
    tmp.close()
    return tmp.name


@st.cache_resource
def load_whisper():
    return whisper.load_model("tiny")


def transcrever(caminho):
    modelo = load_whisper()
    resultado = modelo.transcribe(caminho, fp16=False)
    return resultado["segments"]


def criar_cortes(segmentos, duracao_minima=30, duracao_maxima=60):
    cortes = []
    inicio = None
    textos = []

    for segmento in segmentos:
        if inicio is None:
            inicio = float(segmento["start"])

        textos.append(segmento["text"].strip())
        fim = float(segmento["end"])

        if fim - inicio >= duracao_minima:
            corte_fim = min(fim, inicio + duracao_maxima)
            cortes.append({
                "inicio": inicio,
                "fim": corte_fim,
                "texto": " ".join(t for t in textos if t),
            })
            inicio = None
            textos = []

    return cortes


def gerar_corte(entrada, inicio, fim, vertical=False):
    saida = tempfile.NamedTemporaryFile(delete=False, suffix=".mp4")
    saida.close()

    filtros = []
    if vertical:
        # 9:16 centralizado. Mantém o vídeo sem esticar.
        filtros.append(
            "scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280"
        )

    comando = [
        "ffmpeg", "-y",
        "-ss", str(inicio),
        "-i", entrada,
        "-t", str(max(0.1, fim - inicio)),
    ]

    if filtros:
        comando += ["-vf", ",".join(filtros)]

    comando += [
        "-c:v", "libx264",
        "-preset", "veryfast",
        "-crf", "23",
        "-c:a", "aac",
        "-movflags", "+faststart",
        saida.name,
    ]

    resultado = subprocess.run(comando, capture_output=True, text=True)
    if resultado.returncode != 0:
        try:
            os.remove(saida.name)
        except OSError:
            pass
        raise RuntimeError(resultado.stderr[-3000:])

    return saida.name


st.markdown("### 🔗 Opção 1 — Link do YouTube")
url = st.text_input("Cole o link aqui", placeholder="https://www.youtube.com/watch?v=...")

if st.button("🔍 Verificar link", use_container_width=True):
    if not url.strip():
        st.warning("⚠️ Cole um link primeiro.")
    elif is_youtube_url(url):
        st.success("✅ Link do YouTube reconhecido!")
        st.info(
            "O DarkCut não usa mais yt-dlp para tentar contornar bloqueios 403. "
            "Para transformar um vídeo do YouTube em MP4, o conteúdo precisa ser "
            "fornecido por uma integração autorizada ou pelo próprio usuário."
        )
    else:
        st.warning("⚠️ Esse não parece ser um link do YouTube.")

st.markdown("### 📤 Opção 2 — Enviar vídeo")
video = st.file_uploader(
    "Escolha um vídeo",
    type=["mp4", "mov", "avi", "mkv"],
)

col1, col2 = st.columns(2)
with col1:
    duracao_minima = st.number_input("Duração mínima (s)", 15, 180, 30, 5)
with col2:
    duracao_maxima = st.number_input("Duração máxima (s)", 15, 180, 60, 5)

vertical = st.checkbox("📱 Gerar corte em 9:16", value=True)

if st.button("🤖 Analisar vídeo", use_container_width=True):
    caminho = None

    try:
        if video is not None:
            with st.spinner("📥 Preparando vídeo..."):
                caminho = save_uploaded_video(video)
        elif url.strip() and is_youtube_url(url):
            st.error(
                "🔒 O link do YouTube foi reconhecido, mas este projeto não vai "
                "baixar vídeos por métodos que contornem o 403. Envie o vídeo "
                "ou conecte uma fonte autorizada."
            )
            st.stop()
        else:
            st.warning("⚠️ Cole um link válido do YouTube ou envie um vídeo.")
            st.stop()

        st.success("🎬 Vídeo recebido!")

        with st.spinner("🧠 Transcrevendo vídeo..."):
            segmentos = transcrever(caminho)

        with st.spinner("✂️ Encontrando cortes..."):
            cortes = criar_cortes(segmentos, duracao_minima, duracao_maxima)

        if not cortes:
            st.warning("Nenhum corte encontrado com a duração escolhida.")
            st.session_state.pop("cortes", None)
        else:
            st.success(f"🔥 {len(cortes)} corte(s) encontrados!")
            st.session_state["cortes"] = cortes
            st.session_state["video"] = caminho

    except Exception as erro:
        st.error("❌ Não foi possível processar o vídeo.")
        st.code(str(erro))


if "cortes" in st.session_state:
    st.markdown("## ✂️ Cortes sugeridos")

    for i, corte in enumerate(st.session_state["cortes"]):
        st.markdown(f"### 🎬 Corte {i + 1}")
        st.write(f"⏱️ {corte['inicio']:.1f}s → {corte['fim']:.1f}s")
        st.write(f"📝 {corte['texto']}")

        if st.button(f"✂️ Gerar Corte {i + 1}", key=f"gerar_{i}", use_container_width=True):
            try:
                with st.spinner("🎬 Gerando MP4..."):
                    saida = gerar_corte(
                        st.session_state["video"],
                        corte["inicio"],
                        corte["fim"],
                        vertical=vertical,
                    )

                with open(saida, "rb") as arquivo:
                    dados = arquivo.read()

                st.success("🎉 Corte criado!")
                st.video(dados)
                st.download_button(
                    "⬇️ Baixar MP4",
                    data=dados,
                    file_name=f"darkcut_corte_{i + 1}.mp4",
                    mime="video/mp4",
                    use_container_width=True,
                    key=f"download_{i}",
                )

                try:
                    os.remove(saida)
                except OSError:
                    pass

            except Exception as erro:
                st.error("❌ Erro ao gerar o MP4.")
                st.code(str(erro))
